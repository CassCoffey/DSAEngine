#pragma once
#include <gl/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <FreeImage.h>
#include <string.h>
#include <vector>
#include "ShaderManager.h"
#include <map>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/euler_angles.hpp>

class Engine
{
public:
	Engine();
	~Engine();

	bool init();
	bool bufferModel();
	bool gameLoop();
	bool useShaders();

	struct Vertex
	{
		glm::vec3 loc;
		glm::vec2 uv;
	};

	struct Transform
	{
		glm::vec3 location, rotation, size;
		glm::mat4 objWorldTransform;
	};

	struct Object
	{
		Transform transform;
		char* texture;
		GLuint glTex;
	};

private:
	GLFWwindow* GLFWwindowPtr;
	GLuint vertArr;
	unsigned int vertCount;
	ShaderManager shaderManager;
	std::vector<Object> objects;
};

