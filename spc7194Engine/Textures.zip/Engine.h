#pragma once
#include <gl/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <FreeImage.h>
#include <vector>
#include "ShaderManager.h"
#include <map>

class Engine
{
public:
	Engine();
	~Engine();

	bool init();
	bool bufferModel();
	bool gameLoop();
	bool useShaders();

	struct Vertex
	{
		glm::vec3 loc;
		glm::vec2 uv;
	};

private:
	GLFWwindow* GLFWwindowPtr;
	GLuint vertArr;
	unsigned int vertCount;
	ShaderManager shaderManager;
};

