#include "Engine.h"

std::map<int, bool> keyIsDown;
std::map<int, bool> keyWasDown;

void mouseClick(GLFWwindow * windowPtr,
	int button, int action, int mods)
{
	keyIsDown[button] = action;
}

void keyCallback(GLFWwindow * window, int key,
	int scancode, int action, int mods)
{
	keyIsDown[key] = action;
}


Engine::Engine()
{
	
}

Engine::~Engine()
{

}

bool Engine::init()
{
	if (glfwInit() == GL_FALSE)
	{
		return false;
	}

	GLFWwindowPtr = glfwCreateWindow(800, 600, "spc7194 DSA1 Engine", NULL, NULL);

	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else
	{
		glfwTerminate();
		return false;
	}

	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return false;
	}

	return true;
}

bool Engine::bufferModel()
{
	std::vector<glm::vec3> locs =
	{ { .9, .9, 0 },
	{ -.9, .9, 0 },
	{ -.9, -.9, 0 },
	{ .9, -.9, 0 } };

	std::vector <unsigned int>
		locInds =
	{ 0, 1, 2,
		0, 2, 3 };

	vertCount = locInds.size();

	std::vector<Vertex> vertBufData(vertCount);
	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i].loc = locs[locInds[i]];
		//vertBufData[i].uv = 
	}

	GLuint vertBuf;

	glGenVertexArrays(1, &vertArr);
	glGenBuffers(1, &vertBuf);

	glBindVertexArray(vertArr);
	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(Vertex) * vertCount,
		&vertBufData[0],
		GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);

	glVertexAttribPointer(
		0,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(Vertex),
		0);

	glEnableVertexAttribArray(1);

	glVertexAttribPointer(
		1,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(Vertex),
		(void*)sizeof(glm::vec3));

	glBindVertexArray(0);

	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);

	return true;
}

bool Engine::gameLoop()
{
	// Set Up Input
	glfwSetMouseButtonCallback(GLFWwindowPtr, mouseClick);
	glfwSetKeyCallback(GLFWwindowPtr, keyCallback);

	// First Texture
	char* texFileOne = "textures/texture.jpg";
	FIBITMAP* imageOne = FreeImage_Load(FreeImage_GetFileType(texFileOne, 0), texFileOne);

	if (imageOne == nullptr) // load failed
	{
		std::cout << "Failed to load texture one." << std::endl;
		glfwTerminate();
		return false;
	}

	FIBITMAP* image32BitOne = FreeImage_ConvertTo32Bits(imageOne);
	FreeImage_Unload(imageOne);

	unsigned int firstTexID;

	glGenTextures(1, &firstTexID);
	glBindTexture(GL_TEXTURE_2D, firstTexID);
	glTexImage2D(GL_TEXTURE_2D, 0,
		GL_SRGB_ALPHA, FreeImage_GetWidth(image32BitOne), FreeImage_GetHeight(image32BitOne), 0, GL_BGRA,
		GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32BitOne));
	glTexParameteri(GL_TEXTURE_2D,
		GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32BitOne);
	glBindTexture(GL_TEXTURE_2D, 0);


	// Second Texture
	char* texFileTwo = "textures/textureTwo.jpg";
	FIBITMAP* imageTwo = FreeImage_Load(FreeImage_GetFileType(texFileTwo, 0), texFileTwo);

	if (imageTwo == nullptr) // load failed
	{
		std::cout << "Failed to load texture two." << std::endl;
		glfwTerminate();
		return false;
	}

	FIBITMAP* image32BitTwo = FreeImage_ConvertTo32Bits(imageTwo);
	FreeImage_Unload(imageTwo);

	unsigned int secondTexID;

	glGenTextures(1, &secondTexID);
	glBindTexture(GL_TEXTURE_2D, secondTexID);
	glTexImage2D(GL_TEXTURE_2D, 0,
		GL_SRGB_ALPHA, FreeImage_GetWidth(image32BitTwo), FreeImage_GetHeight(image32BitTwo), 0, GL_BGRA,
		GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32BitTwo));
	glTexParameteri(GL_TEXTURE_2D,
		GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32BitTwo);
	glBindTexture(GL_TEXTURE_2D, 0);

	bool texSwap = false;

	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{
		keyWasDown = keyIsDown;
		glfwPollEvents();

		glClear(GL_COLOR_BUFFER_BIT);

		if (texSwap)
		{
			glBindTexture(GL_TEXTURE_2D, secondTexID);
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, firstTexID);
		}
		
		glBindVertexArray(vertArr);
		glDrawArrays(GL_TRIANGLES, 0, vertCount);
		glBindVertexArray(0);

		glfwSwapBuffers(GLFWwindowPtr);

		if (keyIsDown[GLFW_KEY_ESCAPE])
		{
			glfwSetWindowShouldClose(GLFWwindowPtr, GL_TRUE);
		}
		if (keyIsDown[GLFW_MOUSE_BUTTON_1] && !keyWasDown[GLFW_MOUSE_BUTTON_1])
		{
			texSwap = !texSwap;
		}
	}

	glDeleteTextures(1, &firstTexID);
	glfwTerminate();

	return true;
}

bool Engine::useShaders()
{
	if (shaderManager.loadShaders("shaders/vShader.glsl", "shaders/fShader.glsl"))
	{
		glUseProgram(shaderManager.getProgram());

		return true;
	}

	return false;
}
