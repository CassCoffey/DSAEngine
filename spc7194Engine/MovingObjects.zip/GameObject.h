#pragma once
#include <glm/glm.hpp>
#include <gl/glew.h>
#include <GLFW/glfw3.h>

struct Vertex
{
	glm::vec3 loc;
	glm::vec2 uv;
};

struct Transform
{
	glm::vec3 location, rotation, size;
	glm::mat4 objWorldTransform;
};

struct RigidBody
{
	glm::vec3 velocity;
	glm::vec3 force;
	float mass;
};

class GameObject
{
public:
	GameObject();
	~GameObject();

	Transform transform;
	char* texture;
	GLuint glTex;
	RigidBody rigidBody;
};

